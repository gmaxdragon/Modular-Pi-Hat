%TF.GenerationSoftware,KiCad,Pcbnew,10.0.6*%
%TF.CreationDate,2026-10-11T19:17:04+00:00*%
%TF.ProjectId,SZSERVOEXTENDER,535a5345-5256-44f4-9558-54454e444552,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.6) date 2026-10-11 19:17:04*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10R,1.700000X1.700000*%
%ADD11C,1.700000*%
%ADD12RoundRect,0.250000X-0.550000X-0.550000X0.550000X-0.550000X0.550000X0.550000X-0.550000X0.550000X0*%
%ADD13C,1.600000*%
%ADD14RoundRect,0.250000X-1.050000X-1.050000X1.050000X-1.050000X1.050000X1.050000X-1.050000X1.050000X0*%
%ADD15C,2.600000*%
G04 APERTURE END LIST*
D10*
%TO.C,J3*%
X106380000Y-132247500D03*
D11*
X106380000Y-134787500D03*
X106380000Y-137327500D03*
%TD*%
D12*
%TO.C,C1*%
X102380000Y-145327500D03*
D13*
X104880000Y-145327500D03*
%TD*%
D14*
%TO.C,J1*%
X95840000Y-159000000D03*
D15*
X100920000Y-159000000D03*
X106000000Y-159000000D03*
X111080000Y-159000000D03*
%TD*%
D10*
%TO.C,J2*%
X100880000Y-132287500D03*
D11*
X100880000Y-134827500D03*
X100880000Y-137367500D03*
%TD*%
M02*
